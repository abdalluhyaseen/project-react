import React, { useRef } from "react";
import "./Hero Section.css";

const SmartSchoolSlider = () => {
  const slideRef = useRef();

  const handleNext = () => {
    const items = slideRef.current.querySelectorAll(".item");
    slideRef.current.appendChild(items[0]);
  };

  const handlePrev = () => {
    const items = slideRef.current.querySelectorAll(".item");
    slideRef.current.prepend(items[items.length - 1]);
  };

  return (
    <div className="container">
      <div className="slide" ref={slideRef}>
        <div className="item" style={{ backgroundImage: "url(imge1.jpeg)" }}>
          <div className="content">
            <div className="name">
              Welcome to{" "}
              <span
                style={{
                  color: "#5DB996",
                  background: "linear-gradient(to right, #5DB996, #118B50)",
                }}
              >
                SmartSchool!
              </span>
            </div>
            <div className="des">
              <h5>
                SmartSchool is a modern and innovative platform designed to
                enhance the learning experience for students, teachers, and
                parents. Here's what makes it unique.
              </h5>
            </div>
          </div>
        </div>
        <div className="item" style={{ backgroundImage: "url(imge2.jpeg)" }}>
          <div className="content">
            <div className="des">
              <h4>
                For Students: Interactive lessons, fun quizzes, and personalized
                learning paths.
              </h4>
            </div>
            <div className="des">
              <h4>
                For Teachers: Easy class management, tools for creating engaging
                content, and real-time analytics on student progress.
              </h4>
            </div>
            <div className="des">
              <h4>
                For Parents: Stay updated with your child's achievements and
                communicate seamlessly with teachers.
              </h4>
            </div>
          </div>
        </div>
        <div className="item" style={{ backgroundImage: "url(imge3.jpeg)" }}>
          <div className="content">
            <div className="des">
              <h4>
                SmartSchool makes learning smarter, simpler, and more exciting
                for everyone! 🌟
              </h4>
            </div>
          </div>
        </div>
      </div>
      <div className="button">
        <button className="prev" onClick={handlePrev}>
          <i className="fa-solid fa-arrow-left"></i>
        </button>
        <button className="next" onClick={handleNext}>
          <i className="fa-solid fa-arrow-right"></i>
        </button>
      </div>
    </div>
  );
};

export default SmartSchoolSlider;
